import greenfoot.*;  

public class Reward extends Actor {
}
