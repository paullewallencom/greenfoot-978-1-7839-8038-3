import greenfoot.*; 

public class BrickWall extends Platform {
}
