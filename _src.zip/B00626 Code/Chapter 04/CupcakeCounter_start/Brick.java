import greenfoot.*;  

public class Brick extends Platform {
}
