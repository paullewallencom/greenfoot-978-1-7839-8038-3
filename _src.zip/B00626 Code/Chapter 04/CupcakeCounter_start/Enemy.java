import greenfoot.*;  

public abstract class Enemy extends Actor {
}
