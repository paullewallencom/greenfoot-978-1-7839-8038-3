import greenfoot.*;  

public class Reward extends Actor {
    public void act() {
    }   
}
