import greenfoot.*; 

public class BrickWall extends Platform {
    public void act() {
    }    
}
