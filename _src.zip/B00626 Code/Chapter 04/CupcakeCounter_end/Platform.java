import greenfoot.*; 

public abstract class Platform extends Actor {
    public void act() {
    }    
}
