import greenfoot.*;

public class Cupcake extends Reward {
    public void act() {
        super.act();
    }    
}
