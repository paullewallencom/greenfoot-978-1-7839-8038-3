import greenfoot.*;  

public abstract class Enemy extends Actor {
    public void act() {
    }    
}
