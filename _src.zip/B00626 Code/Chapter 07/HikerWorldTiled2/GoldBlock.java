import greenfoot.*;

public class GoldBlock extends ScrollingActor {
}
