import greenfoot.*;

public class BlackBlock extends ScrollingObstacle {
}
