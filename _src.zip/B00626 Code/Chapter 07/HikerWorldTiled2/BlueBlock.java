import greenfoot.*;

public class BlueBlock extends ScrollingObstacle {
}
