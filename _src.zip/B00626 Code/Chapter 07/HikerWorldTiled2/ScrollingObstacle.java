import greenfoot.*;

public class ScrollingObstacle extends ScrollingActor {
}
