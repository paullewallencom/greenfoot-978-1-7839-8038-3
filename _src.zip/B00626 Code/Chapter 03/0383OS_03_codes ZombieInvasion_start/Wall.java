import greenfoot.*;  
import java.util.List;

public class Wall extends Actor {
    int wallStrength = 2000;
    int wallStage = 0;
    
    public void act() {
        crumble();
    } 
    
    private void crumble() {
    }
}
