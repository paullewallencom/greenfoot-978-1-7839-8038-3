public class Zombie1 extends Zombie {
}
