public class Zombie2 extends Zombie {      
}
