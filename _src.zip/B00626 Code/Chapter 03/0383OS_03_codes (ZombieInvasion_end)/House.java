import greenfoot.*;

public class House extends Actor {
}
