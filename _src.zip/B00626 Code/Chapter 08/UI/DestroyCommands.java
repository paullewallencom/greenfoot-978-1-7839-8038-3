import greenfoot.*;

public class DestroyCommands implements MenuCommands {
    public void execute(int idx, World w) {
        System.out.println("Boooom!!!!");
    }
}
