import greenfoot.*;

public interface MenuCommands {
    public void execute(int idx, World w);
}
