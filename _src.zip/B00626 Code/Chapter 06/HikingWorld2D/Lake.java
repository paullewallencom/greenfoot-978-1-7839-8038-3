import greenfoot.*;

public class Lake extends ScrollingActor {
}
