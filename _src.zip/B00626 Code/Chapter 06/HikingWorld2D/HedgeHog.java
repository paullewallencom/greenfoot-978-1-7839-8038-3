import greenfoot.*;

public class HedgeHog extends ScrollingActor {
}
