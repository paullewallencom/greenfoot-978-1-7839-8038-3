import greenfoot.*;

public class Lemur extends ScrollingActor {
}
