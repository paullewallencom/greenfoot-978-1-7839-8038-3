import greenfoot.*;  
public class Wall extends Obstacle {
}
