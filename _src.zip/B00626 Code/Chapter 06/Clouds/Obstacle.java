import greenfoot.*;

public class Obstacle extends SideScrollingActor{
}
