import greenfoot.*;

public class WhiteBlock extends ScrollingActor {
}
