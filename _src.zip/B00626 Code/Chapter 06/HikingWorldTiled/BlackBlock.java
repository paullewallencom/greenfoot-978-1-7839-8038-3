import greenfoot.*;

public class BlackBlock extends ScrollingActor {
}
